# Healthcare Data Quality Agent Prototype

A small, reproducible Python prototype for detecting common healthcare data-quality issues in a synthetic patient dataset.

## What it checks
- Invalid dates
- Future dates of birth
- Missing diagnosis values
- Duplicate patient identifiers

## Run

```bash
python data_quality.py
```

This project uses synthetic data only. It contains no real patient information.
