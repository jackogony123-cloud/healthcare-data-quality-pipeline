# I Built a Small Healthcare Data-Quality Pipeline. The Interesting Part Wasn't the Python.

I work with healthcare information, so I have seen the same data-quality problem in different forms: a record can look complete to a person and still be unusable to a system.

A missing diagnosis, an impossible date, or two records sharing a patient identifier can quietly travel downstream into reporting, claims, analytics, or operational workflows.

I wanted to build something small enough to understand end to end rather than start with an elaborate AI architecture. So I created a synthetic patient dataset and wrote a Python validation pipeline to find a few common failures.

The first version deliberately did not use an LLM. I wanted a baseline I could measure before adding anything probabilistic.

## The dataset

I generated 105 synthetic patient rows with four fields: `patient_id`, `dob`, `sex`, and `diagnosis`.

I then introduced deliberate problems: invalid dates, future dates of birth, missing diagnoses, and duplicate patient identifiers.

The data is synthetic. No real patient information is involved.

## The first pass

The validator is intentionally boring. For each row, it parses the date, checks whether the date is in the future, checks for a missing diagnosis, and then counts duplicate patient identifiers.

That produced a list of issues instead of silently changing the source data.

This design choice matters. A data-quality tool should tell me what is wrong before it starts “fixing” anything. Automatic correction is a separate risk decision.

## What surprised me

The most interesting failure was not the invalid date. It was the duplicate identifier.

A duplicate `patient_id` looks trivial in a small CSV. In a real system, however, the same identifier appearing on multiple records could mean several different things: a legitimate repeated encounter, an accidental duplicate, or a much more serious identity problem.

The validator can detect the pattern. It cannot safely infer the correct action.

That is where I think AI is useful—but only after deterministic checks have done the work they are good at.

## Where I would add an agent

I would not ask an LLM to replace the validation rules.

Instead, I would give an agent a narrow investigation job.

For a flagged duplicate, the agent could inspect an approved set of fields, compare the records, explain why they look similar or different, and produce a recommendation for human review.

For example:

```text
Validator
   |
   v
Duplicate detected
   |
   v
Agent investigates permitted fields
   |
   +----> Strong evidence of duplicate -> Human review
   |
   +----> Evidence is weak -----------> Human review
   |
   +----> Clearly legitimate repeat --- > Close alert
```

The important part is that the agent would not receive unrestricted access to the patient database, and it would not be allowed to merge records on its own.

## Why I would keep the rules deterministic

There are tasks where I want exactly the same input to produce exactly the same decision.

“Is `31/02/1980` a valid date?” is one of them.

There is no reason to spend tokens on an LLM for a question that a date parser can answer reliably.

The LLM becomes more interesting when the task changes from validation to investigation: *Why might these two records represent the same person? What evidence supports that conclusion? What information is still missing?*

That separation gives me a cleaner architecture:

**deterministic validation → targeted AI investigation → human decision**

rather than:

**send the database to an LLM and hope it figures things out.**

## What I would build next

The prototype is deliberately small, but it gives me a baseline for the next version.

I would add:

1. A SQLite/PostgreSQL storage layer.
2. A schema and data-quality rule registry.
3. An audit log for every validation and agent action.
4. A small API for submitting records and retrieving quality alerts.
5. A human-review queue for high-risk issues.
6. An LLM tool restricted to investigating individual alerts rather than modifying source data.
7. Evaluation metrics for false positives, false negatives, and human overrides.

The goal would not be to make the system “more AI.” The goal would be to make the workflow more useful without making the data less trustworthy.

## The lesson

Building this small pipeline reinforced something I have learned from healthcare data work: the difficult part is rarely detecting that something looks wrong.

The difficult part is deciding what you are allowed to do about it.

That is why I would design an AI data-quality system around **bounded actions, explicit permissions, auditability, and human review**.

AI can investigate a problem much faster than a person can search through hundreds of records. But speed is only valuable when the system knows where its authority ends.
