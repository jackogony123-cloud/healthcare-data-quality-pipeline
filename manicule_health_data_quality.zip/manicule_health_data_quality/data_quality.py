import pandas as pd
from datetime import datetime

INPUT = "patients.csv"
OUTPUT = "quality_issues.csv"


def validate(df):
    issues = []
    today = datetime.now().date()

    for _, row in df.iterrows():
        try:
            dob = datetime.strptime(row["dob"], "%d/%m/%Y").date()
            if dob > today:
                issues.append((row["patient_id"], "future_dob", row["dob"]))
        except ValueError:
            issues.append((row["patient_id"], "invalid_dob", row["dob"]))

        if pd.isna(row["diagnosis"]) or str(row["diagnosis"]).strip() == "":
            issues.append((row["patient_id"], "missing_diagnosis", ""))

    duplicate_counts = df["patient_id"].value_counts()
    for patient_id, count in duplicate_counts.items():
        if count > 1:
            issues.append((patient_id, "duplicate_patient_id", str(count)))

    return pd.DataFrame(issues, columns=["patient_id", "issue", "detail"])


if __name__ == "__main__":
    patients = pd.read_csv(INPUT)
    issues = validate(patients)
    issues.to_csv(OUTPUT, index=False)
    print(f"Checked {len(patients)} records")
    print(f"Found {len(issues)} quality issues")
    print(issues.to_string(index=False))
